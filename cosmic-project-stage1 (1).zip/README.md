# Cosmic — industrial space hardcore simulator (Minecraft 1.20.1, Forge)

Stage 1 skeleton: CI/CD, Gradle configuration, core mod class and
self-organizing creative tabs.

## Build locally

    gradle wrapper --gradle-version 8.4
    ./gradlew build

JAR output: `build/libs/cosmic-<version>.jar`

## CI/CD

GitHub Actions builds the mod on every push to `main`/`develop`.
If `gradlew` is missing, the workflow installs Gradle 8.4 and generates
the wrapper automatically, then uploads `cosmic-*.jar` as an artifact.

## Roadmap

| Stage | Content |
|-------|---------|
| 1 | Project skeleton, CI, creative tabs |
| 2 | 120+ ores, ingots, plates, chemicals, fluids and gases |
| 3 | ISS modules, airlocks, oxygen sealing (BFS), hazards |
| 4 | 6 suits, HUD visor, Curios gear, satellites, mission control |
| 5 | Multiblock industry, cryogenics, reactors, wear & chain failures |
| 6 | 85+ rocket parts, 3D assembly bay GUI (Mass / TWR / Delta-V) |
| 7 | Rocket entity, KSP piloting, re-entry, crash craters, black box |
| 8 | 8 dimensions JSON, custom skyboxes, NASA sound library, JEI |

No mobs. No magic. Only physics.
