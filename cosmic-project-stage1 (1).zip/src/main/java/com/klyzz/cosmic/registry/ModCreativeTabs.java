package com.klyzz.cosmic.registry;

import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public final class ModCreativeTabs {

    private ModCreativeTabs() {}

    private static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CosmicMod.MODID);

    /** Per-category index: everything registered by content later fills these. */
    private static final Map<TabMember.TabCategory, List<Supplier<? extends ItemLike>>> INDEX =
            new EnumMap<>(TabMember.TabCategory.class);

    static {
        for (TabMember.TabCategory c : TabMember.TabCategory.values()) {
            INDEX.put(c, new ArrayList<>());
        }
    }

    public static final RegistryObject<CreativeModeTab> RESOURCES = register("resources",
            TabMember.TabCategory.RESOURCES, () -> new ItemStack(Items.RAW_IRON));
    public static final RegistryObject<CreativeModeTab> MACHINES = register("machines",
            TabMember.TabCategory.MACHINES, () -> new ItemStack(Items.PISTON));
    public static final RegistryObject<CreativeModeTab> ROCKETRY = register("rocketry",
            TabMember.TabCategory.ROCKETRY, () -> new ItemStack(Items.FIREWORK_ROCKET));
    public static final RegistryObject<CreativeModeTab> STATIONS = register("stations",
            TabMember.TabCategory.STATIONS, () -> new ItemStack(Items.WHITE_CONCRETE));
    public static final RegistryObject<CreativeModeTab> GEAR = register("gear",
            TabMember.TabCategory.GEAR, () -> new ItemStack(Items.IRON_CHESTPLATE));
    public static final RegistryObject<CreativeModeTab> FLUIDS = register("fluids",
            TabMember.TabCategory.FLUIDS, () -> new ItemStack(Items.WATER_BUCKET));

    private static RegistryObject<CreativeModeTab> register(String name,
                                                            TabMember.TabCategory category,
                                                            Supplier<ItemStack> icon) {
        return TABS.register(name, () -> CreativeModeTab.builder()
                .title(Component.translatable("itemGroup.cosmic." + name))
                .icon(icon)
                .displayItems((params, output) -> {
                    for (Supplier<? extends ItemLike> entry : INDEX.get(category)) {
                        output.accept(entry.get());
                    }
                })
                .build());
    }

    /** Called by item/block registration code in later stages. */
    public static void addToTab(TabMember.TabCategory category, Supplier<? extends ItemLike> item) {
        INDEX.get(category).add(item);
    }

    public static void register(IEventBus modBus) {
        TABS.register(modBus);
    }
}
