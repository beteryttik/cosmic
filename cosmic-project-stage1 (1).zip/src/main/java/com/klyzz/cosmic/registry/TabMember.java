package com.klyzz.cosmic.registry;

/**
 * Implemented by any Cosmic item or block item to declare
 * which creative tab(s) it belongs to. Tabs are self-organizing:
 * no central registry edit is required when new content is added
 * in later stages.
 */
public interface TabMember {

    /** Categories this entry appears in. May return several. */
    TabCategory[] categories();

    enum TabCategory {
        RESOURCES,
        MACHINES,
        ROCKETRY,
        STATIONS,
        GEAR,
        FLUIDS
    }
}
