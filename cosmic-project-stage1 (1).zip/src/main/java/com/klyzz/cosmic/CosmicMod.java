package com.klyzz.cosmic;

import com.klyzz.cosmic.registry.ModCreativeTabs;
import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(CosmicMod.MODID)
public class CosmicMod {

    public static final String MODID = "cosmic";
    public static final Logger LOGGER = LogUtils.getLogger();

    public CosmicMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModCreativeTabs.register(modBus);

        modBus.addListener(this::commonSetup);

        MinecraftForge.EVENT_BUS.register(this);

        LOGGER.info("Cosmic: mission control online. Hard vacuum, zero magic.");
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        logDependency("geckolib");
        logDependency("create");
        logDependency("curios");
        logDependency("jei");
    }

    private static void logDependency(String modId) {
        boolean present = ModList.get().isLoaded(modId);
        if (present) {
            LOGGER.info("Cosmic: integration module [{}] detected.", modId);
        } else {
            LOGGER.warn("Cosmic: integration module [{}] NOT found - some features will be degraded.", modId);
        }
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MODID, path);
    }
}
